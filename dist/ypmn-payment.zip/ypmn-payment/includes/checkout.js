const ypmn_settings = window.wc.wcSettings.getSetting( 'ypmn_data', {} );
const ypmn_label = window.wp.htmlEntities.decodeEntities( ypmn_settings.title ) || window.wp.i18n.__( 'Ypmn payment', 'ypmn-payment' );
const YpmnContent = () => {
    return window.wp.htmlEntities.decodeEntities( ypmn_settings.description || '' );
};
const Ypmn_Block_Gateway = {
    name: 'ypmn',
    label: ypmn_label,
    content: Object( window.wp.element.createElement )( YpmnContent, null ),
    edit: Object( window.wp.element.createElement )( YpmnContent, null ),
    canMakePayment: () => true,
    ariaLabel: ypmn_label,
    supports: {
        features: ypmn_settings.supports,
    },
};
window.wc.wcBlocksRegistry.registerPaymentMethod( Ypmn_Block_Gateway );