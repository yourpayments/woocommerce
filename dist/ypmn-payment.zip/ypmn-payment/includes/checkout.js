const ypmnpayment_settings = window.wc.wcSettings.getSetting( 'ypmnpayment_data', {} );
const ypmnpayment_label = window.wp.htmlEntities.decodeEntities( ypmnpayment_settings.title ) || window.wp.i18n.__( 'Ypmn payment', 'ypmn-payment' );
const YpmnPaymentContent = () => {
    return window.wp.htmlEntities.decodeEntities( ypmnpayment_settings.description || '' );
};
const Ypmnpayment_Block_Gateway = {
    name: 'ypmnpayment',
    label: ypmnpayment_label,
    content: Object( window.wp.element.createElement )( YpmnPaymentContent, null ),
    edit: Object( window.wp.element.createElement )( YpmnPaymentContent, null ),
    canMakePayment: () => true,
    ariaLabel: ypmnpayment_label,
    supports: {
        features: ypmnpayment_settings.supports,
    },
};
window.wc.wcBlocksRegistry.registerPaymentMethod( Ypmnpayment_Block_Gateway );