<?php
if ( ! defined( 'ABSPATH' ) ) exit;

use Ypmn\Product;
use Ypmn\ApiRequest;
use Ypmn\Merchant;
use Ypmn\Refund;
use Ypmn\Capture;

class Ypmn_Info_Page
{
	private $settings;

	public function __construct()
	{
		$this->settings    = get_option('woocommerce_ypmn_settings');
	}

	public function display()
	{
		global $wpdb;

		$idRequest = sanitize_text_field(wp_unslash($_GET['merchant_payment_reference'] ?? ''));

		$info      = $wpdb->get_row($wpdb->prepare("
			SELECT *
			FROM {$wpdb->prefix}ypmn
			WHERE merchant_payment_reference=%s", $idRequest));
		if (!$info) {
			wp_die(esc_html(__('Not Found', 'ypmn-payment')));
		}
		$tab = sanitize_text_field(wp_unslash($_GET['tab'] ?? null));
		?>
		<div class='wrap'>
			<h2>
				<?php echo esc_html(__("Information order № ", 'ypmn-payment')) . esc_html($info->order_number); ?>
				<?php wc_back_link(__('Transaction list', 'ypmn-payment'), add_query_arg(['_wpnonce' => false, 'section' => false, 'merchant_payment_reference' => false]));?>
				</h2>
				<?php $this->showMessages();?>
			<nav class="nav-tab-wrapper">
				<a href="?page=ypmn&section=info&merchant_payment_reference=<?php echo esc_attr($idRequest)?>" class="nav-tab <?php if ($tab === null): ?>nav-tab-active<?php endif;?>"><?php echo esc_html(__('Information', 'ypmn-payment'));?></a>
				<a href="?page=ypmn&section=info&merchant_payment_reference=<?php echo esc_attr($idRequest)?>&tab=operations" class="nav-tab <?php if ($tab === 'operations'): ?>nav-tab-active<?php endif;?>"><?php echo esc_html(__('Operations', 'ypmn-payment'))?></a>
			</nav>
			<div class="tab-content">
				<?php if ($tab === 'operations') {
			$this->operations($info);
		} else {
			$this->info($info);
		}?>
			</div>
		</div>
			<?php
}

	private function info($info)
	{
		?>
		<table class="wp-list-table widefat fixed striped table-view-list">
			<tbody class="the-list">
				<tr>
					<td><?php echo esc_html(__('Id request', 'ypmn-payment'));?></td>
					<td><?php echo esc_html($info->merchant_payment_reference) ?></td>
				</tr>
				<tr>
					<td><?php echo esc_html(__('Order id', 'ypmn-payment'));?></td>
					<td><?php echo esc_html($info->order_id) ?></td>
				</tr>
				<tr>
					<td><?php echo esc_html(__('Order number', 'ypmn-payment'));?></td>
					<td><?php echo esc_html($info->order_number) ?></td>
				</tr>
				<tr>
					<td><?php echo esc_html(__('Status', 'ypmn-payment'));?></td>
					<td><?php echo esc_html($info->payment_status) ?></td>
				</tr>
				<tr>
					<td><?php echo esc_html(__('PayuPaymentReference', 'ypmn-payment'));?></td>
					<td><?php echo esc_html($info->payu_payment_reference) ?></td>
				</tr>
				<tr>
					<td><?php echo esc_html(__('Date', 'ypmn-payment'));?></td>
					<td><?php echo esc_html($info->date) ?></td>
				</tr>
			</tbody>
		</table>
		<?php
}

	private function operations($info)
	{
		$action_nonce = wp_create_nonce('ypmn_action');
		$products      = false;
		if ($info->products) {
			$products = json_decode($info->products, true);
		}
		?>
		<form method="POST" action="" id="ypmn_operation_form">
			<table class="wp-list-table widefat fixed striped table-view-list">
				<tr><td>
				<?php if (in_array($info->payment_status, ['COMPLETE'])): ?>
				<?php if ($products): ?>
					<h2><?php echo esc_html(__('Refund positions', 'ypmn-payment'));?></h2>
					<table class="wp-list-table widefat fixed striped table-view-list">
						<thead>
							<tr>
								<td></td>
								<td>
									<strong><?php echo esc_html(__('Name', 'ypmn-payment'));?></strong>
								</td>
								<td>
									<strong><?php echo esc_html(__('Quantity', 'ypmn-payment'));?></strong>
								</td>
								<td>
									<strong><?php echo esc_html(__('Price', 'ypmn-payment'));?></strong>
								</td>
							</tr>
						</thead>
						<tbody>
						<?php foreach ($products as $id => $item): ?>
							<tr>
								<td>
									<input class="ypmn_payment_position" id="ypmn_payment_position_<?php echo esc_attr($id)?>" type="checkbox" name="position[]" value="<?php echo esc_attr($id)?>" checked>
								</td>
								<td>
									<input size="50" type="hidden" name="name[<?php echo esc_attr($id)?>]" value="<?php echo esc_attr($item['name'])?>">
									<label for="ypmn_payment_position_<?php echo esc_attr($id)?>"><?php echo esc_attr($item['name'])?></label>
								</td>
								<td>
									<input size="7" id="ypmn_payment_qty_<?php echo esc_attr($id)?>" class="ypmn_payment_qty" type="text" name="qty[<?php echo esc_attr($id)?>]" value="<?php echo esc_attr($item['qty'] ?? 1)?>">
								</td>
								<td>
									<input size="7" id="ypmn_payment_price_<?php echo esc_attr($id)?>" class="ypmn_payment_price" type="text" readonly name="unitPrice[<?php echo esc_attr($id)?>]" value="<?php echo esc_attr($item['unitPrice'])?>">
								</td>
							</tr>
						<?php endforeach;?>
						</tbody>
					</table>
				</td>
			</tr><tr>
		<td>
		<?php else: ?>
			<input type="text" name="amount" value="<?php echo esc_html($info->amount)?>">
		<?php endif;?>
			<button class="button" type="submit" name="action" value="refund"><?php echo esc_html(__('Refund', 'ypmn-payment'))?></button>
		<?php endif;?>
		<?php if (in_array($info->payment_status, ['PAYMENT_AUTHORIZED'])): ?>
			<?php if ($products): ?>
					<h2><?php echo esc_html(__('Capture positions', 'ypmn-payment'));?></h2>
					<table class="wp-list-table widefat fixed striped table-view-list">
						<thead>
							<tr>
								<td></td>
								<td>
									<strong><?php echo esc_html(__('Name', 'ypmn-payment'));?></strong>
								</td>
								<td>
									<strong><?php echo esc_html(__('Quantity', 'ypmn-payment'));?></strong>
								</td>
								<td>
									<strong><?php echo esc_html(__('Price', 'ypmn-payment'));?></strong>
								</td>
							</tr>
						</thead>
						<tbody>
						<?php foreach ($products as $id => $item): ?>
							<tr>
								<td >
									<input class="ypmn_payment_position" id="ypmn_payment_position_<?php echo esc_attr($id)?>" type="checkbox" name="position[]" value="<?php echo esc_attr($id)?>" checked readonly>
								</td>
								<td >
									<input size="50" type="hidden" name="name[<?php echo esc_attr($id)?>]" value="<?php echo esc_attr($item['name'])?>">
									<label for="ypmn_payment_position_<?php echo esc_attr($id)?>"><?php echo esc_attr($item['name'])?></label>
								</td>
								<td >
									<input size="7" id="ypmn_payment_qty_<?php echo esc_attr($id)?>" class="ypmn_payment_qty" type="text" name="qty[<?php echo esc_attr($id)?>]" value="<?php echo esc_attr($item['qty'] ?? 1)?>" readonly>
								</td>
								<td >
									<input size="7" id="ypmn_payment_price_<?php echo esc_attr($id)?>" class="ypmn_payment_price" type="text" readonly name="unitPrice[<?php echo esc_attr($id)?>]" value="<?php echo esc_attr($item['unitPrice'])?>">
								</td>
							</tr>
						<?php endforeach;?>
						</tbody>
					</table>
				</td>
			</tr>
			<tr>
		<td>
		<?php else: ?>
			<input type="text" name="amount" value="<?php echo esc_html($info->amount_authorized)?>">
		<?php endif;?>
			<button class="button" type="submit" name="action" value="capture"><?php echo esc_html(__('Capture', 'ypmn-payment'))?></button>
			<button class="button" type="submit" name="action" value="cancel"><?php echo esc_html(__('Cancel', 'ypmn-payment'))?></button>
		<?php endif;?>
			<input type="hidden" name="_wpnonce" value="<?php echo esc_html($action_nonce);?>">
		</td></tr>
		</table>
		</form>
		<?php
}

	public function processAction()
	{
		global $wpdb;

		$idRequest = isset($_GET['merchant_payment_reference']) ? sanitize_text_field(wp_unslash($_GET['merchant_payment_reference'])): null;
		$action    = isset($_POST['action']) ? sanitize_text_field(wp_unslash($_POST['action'])) : null;
		if (!$idRequest) {
			return;
		}
		if (!$action) {
			return;
		}

		if (empty($_REQUEST['_wpnonce'])) {
			return;
		}
		$nonce = sanitize_text_field(wp_unslash($_REQUEST['_wpnonce']));

		if (!wp_verify_nonce($nonce, 'ypmn_action')) {
			die('');
		}


		$info = $wpdb->get_row($wpdb->prepare("
			SELECT *
			FROM {$wpdb->prefix}ypmn
			WHERE merchant_payment_reference=%s", $idRequest));
		if (!$info) {
			wp_die(esc_html(__('Not Found', 'ypmn-payment')));
		}

		try {
			switch ($action) {
				case 'refund':
					$data = [
						'position' => array_map('absint',$_POST['position'] ?? []),
						'quantity' => array_map('absint',$_POST['qty'] ?? []),
						'amount' => sanitize_text_field(wp_unslash($_POST['amount'] ?? 0))
					];
					$result = $this->refundOrder($info, $data);
					break;
				case 'cancel':$result = $this->cancelOrder($info);
					break;
				case 'capture':
					$data = [
						'position' => array_map('absint',$_POST['position'] ?? []),
						'quantity' => array_map('absint',$_POST['qty'] ?? []),
						'amount' => sanitize_text_field(wp_unslash($_POST['amount'] ?? 0))
					];
					$result = $this->captureOrder($info, $data);
					break;
			}
		} catch (\Exception $e) {
			$this->setMessage($e->getMessage(), 'error');
			return;
		}


		$wcStatus = '';
		switch ($result) {
			case 'CANCELED':$wcStatus = 'cancelled';
				break;
			case 'REFUND':$wcStatus = 'refunded';
				break;
			case 'COMPLETE':$wcStatus = 'completed';
				break;
		}
		if ($wcStatus) {
			list($orderId, ) = explode('.', $info->merchant_payment_reference);
			$order   = wc_get_order($orderId);
			$order->update_status($wcStatus);
		}
		$this->setMessage(__('Success operation', 'ypmn-payment'));
	}

	private function refundOrder($info, $data)
	{
		global $wpdb;
		$refund = new Refund();
		$refund->setYpmnPaymentReference($info->payu_payment_reference);

		$refund->setCurrency('RUB');

		$apiRequest = $this->getApi();

		$merchant = $this->getMerchant();

		$products = $info->products;
		if ($products) {
			$refundAmount = 0;
			$receipt      = $refundReceipt      = json_decode($products, true);
			$refundItems  = [];
			foreach ($data['position'] as $id) {
				if (!$data['quantity'][$id]) {
					continue;
				}

				$item        = $refundReceipt[$id];
				$item['quantity'] = intval($data['quantity'][$id]);
				$receipt[$id]['quantity'] -= $item['quantity'];
				$refundAmount += $item['quantity'] * $item['unitPrice'];

				if ($receipt[$id]['quantity'] == 0) {
					unset($receipt[$id]);
				}

				$item['unitPrice'] = floatval($item['unitPrice']);
				$item['amount'] = $item['unitPrice'] * $item['quantity'];
				$refund->addProduct(new Product($item));
			}
			$receipt                      = wp_json_encode($receipt);
			$data['amount'] = $refundAmount;
		}


		$refund->setOriginalAmount($info->amount);
		$refund->setAmount($data['amount']);


		$responseData = $apiRequest->sendRefundRequest($refund);

		$responseData = json_decode((string) $responseData["response"], true);

		if ($responseData['status'] === 'SUCCESS') {
			$wpdb->update("{$wpdb->prefix}ypmn", ['products' => $receipt, 'payment_status' => 'REFUND'], ['merchant_payment_reference' => $info->merchant_payment_reference]);
			return 'REFUND';
		}
		throw new \Exception(esc_html($responseData['message']));
	}

	private function captureOrder($info, $data)
	{
		global $wpdb;
		$capture = new Capture();
		$capture->setYpmnPaymentReference($info->payu_payment_reference);

		$capture->setCurrency('RUB');

		$apiRequest = $this->getApi();

		$merchant = $this->getMerchant();

		$products = $info->products;

		if ($products) {
			$amount  = 0;
			$receipt = json_decode($products, true);
			$items   = [];
			foreach ($data['position'] as $id) {
				if (!$data['quantity'][$id]) {
					continue;
				}
				$item        = $receipt[$id];
				$amount += $item['quantity'] * $item['unitPrice'];
			}
			$data['amount'] = $amount;
		}

		$capture->setOriginalAmount($info->amount);
		$capture->setAmount($data['amount']);


		$responseData = $apiRequest->sendCaptureRequest($capture);

		$responseData = json_decode((string) $responseData["response"], true);

		if ($responseData['status'] === 'SUCCESS') {
			$wpdb->update("{$wpdb->prefix}ypmn", ['payment_status' => 'COMPLETE'], ['merchant_payment_reference' => $info->merchant_payment_reference]);
			return 'COMPLETE';
		}
		throw new \Exception(esc_html($responseData['message']));
		return $result;
	}

	public function cancelOrder($info)
	{

		global $wpdb;
		$refund = new Refund();
		$refund->setYpmnPaymentReference($info->payu_payment_reference);

		$refund->setCurrency('RUB');

		$apiRequest = $this->getApi();

		$merchant = $this->getMerchant();

		$refund->setOriginalAmount($info->amount);
		$refund->setAmount($info->amount);


		$responseData = $apiRequest->sendRefundRequest($refund);

		$responseData = json_decode((string) $responseData["response"], true);

		if ($responseData['status'] === 'SUCCESS') {
			$wpdb->update("{$wpdb->prefix}ypmn", ['payment_status' => 'REVERSED'], ['merchant_payment_reference' => $info->merchant_payment_reference]);
			return 'CANCELED';
		}
		throw new \Exception(esc_html($responseData['message']));

	}

	protected function getMerchant()
	{
		$merchant = new Merchant(
			$this->settings['merchant_code'],
			htmlspecialchars_decode($this->settings['secret_key'])
		);
		return $merchant;
	}

	protected function getApi()
	{
		$merchant = $this->getMerchant();

		$apiRequest = new ApiRequest($merchant);

		//$apiRequest->setDebugMode();

		if ($this->settings['test_mode']) {
			$apiRequest->setSandboxMode();
		}
		return $apiRequest;
	}

	private function showMessages()
	{
		$transient_id = get_current_user_id() . 'ypmn_action_message';
		if ($message = get_transient($transient_id)) {
			delete_transient($transient_id);
			echo sprintf("<div class='notice notice-%s is-dismissible'> <p>%s </p></div>", esc_html($message['type']), esc_html($message['text']));
		}
	}

	private function setMessage($text, $type = 'success')
	{
		$transient_id = get_current_user_id() . 'ypmn_action_message';
		$message      = [
			'type' => $type,
			'text' => $text,
		];
		set_transient($transient_id, $message);
	}

}
