<?php
use Ypmn\ApiRequest;
use Ypmn\Authorization;
use Ypmn\Billing;
use Ypmn\Client;
use Ypmn\Merchant;
use Ypmn\Payment;
use Ypmn\Product;
use Ypmn\PaymentMethods;

if (!defined('ABSPATH')) {
	exit;
}
// Exit if accessed directly

/**
 * Ypmn Payment Gateway
 *
 * Provides a ypmn Payment Gateway.
 *
 * @class 		Ypmn_Payment_Gateway
 * @extends		WC_Payment_Gateway
 * @version		1.0.0
 * @author 		ypmn
 */
class Ypmn_Payment_Gateway extends WC_Payment_Gateway
{

	public $notify_url;
	protected $logger;
	public $id             = 'ypmn';
	public $payment_method = PaymentMethods::CCVISAMC;
	public $secret_key;
	public $test_mode;
	public $product_list;
	public $fiscalisation;
	public $product_tax_id;
	public $delivery_tax_id;
	public $ypmn_logging;

	/**
	 * Constructor for the gateway.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct()
	{
		$this->has_fields = false;
		$this->supports   = array(
			'products',
		);

		$this->setMethodDescription();

		// Load the settings.
		$this->init_form_fields();
		$this->init_settings();

		// Define user set variables
		$this->title           = $this->get_option('title');
		$this->description     = $this->get_option('description');
		$this->instructions    = $this->get_option('instructions', $this->description);
		$this->merchant_code   = $this->get_option('merchant_code');
		$this->secret_key      = htmlspecialchars_decode($this->get_option('secret_key'));
		$this->test_mode       = $this->get_option('test_mode');
		$this->product_list    = $this->get_option('product_list');
		$this->product_tax_id  = $this->get_option('product_tax_id');
		$this->delivery_tax_id = $this->get_option('delivery_tax_id');
		$this->ypmn_logging    = $this->get_option('ypmn_logging');

		$this->logger = wc_get_logger();

		// Actions

		add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
		add_filter('woocommerce_thankyou_order_received_text', array($this, 'return_handler'), 10, 2);

		// Payment listener/API hook
		add_action('woocommerce_api_ypmn_payment_gateway', array($this, 'notification'));

		if (!$this->is_valid_for_use()) {
			$this->enabled = false;
		}
	}

	protected function setMethodDescription()
	{
		$this->order_button_text  = __('Pay', 'ypmn-payment');
		$this->method_title       = __('Ypmn: Internet acquiring', 'ypmn-payment');
		$this->notify_url         = WC()->api_request_url('Ypmn_Payment_Gateway');
		$this->method_description = __('Pay by Card', 'ypmn-payment');
	}

	/**
	 * Check if this gateway is enabled and available in the user's country
	 *
	 * @access public
	 * @return bool
	 */
	public function is_valid_for_use()
	{
		if (!in_array(get_woocommerce_currency(), apply_filters('woocommerce_ypmn_payment_supported_currencies', array('RUB')))) {
			return false;
		}

		return true;
	}

	/**
	 * Admin Panel Options
	 * - Options for bits like 'title' and availability on a country-by-country basis
	 *
	 * @since 1.0.0
	 */
	public function admin_options()
	{
		if ($this->is_valid_for_use()) {
			parent::admin_options();
		} else {
			?>
			<div class="inline error"><p><strong><?php esc_html_e('Gateway Disabled', 'woocommerce'); ?></strong>: <?php echo esc_html('Ypmn does not support your store currency.'); ?></p></div>
			<?php
}
	}

	/**
	 * Initialise Gateway Settings Form Fields
	 *
	 * @access public
	 * @return void
	 */
	public function init_form_fields()
	{
		$this->form_fields = array(
			'enabled'         => array(
				'title'   => __('Enable/Disable', 'woocommerce'),
				'type'    => 'checkbox',
				'label'   => $this->getEnableFieldLabelTitle(),
				'default' => 'yes',
			),
			'title'           => array(
				'title'       => __('Title', 'woocommerce'),
				'type'        => 'text',
				'description' => __('This controls the title which the user sees during checkout.', 'woocommerce'),
				'default'     => $this->getDefaultTitle(),
				'desc_tip'    => true,
			),
			'description'     => array(
				'title'       => __('Description', 'woocommerce'),
				'type'        => 'textarea',
				'description' => __('Payment method description that the customer will see on your checkout.', 'woocommerce'),
				'default'     => '',
				'desc_tip'    => true,
			),
			'instructions'    => array(
				'title'       => __('Instructions', 'woocommerce'),
				'type'        => 'textarea',
				'description' => __('Instructions that will be added to the thank you page and emails.', 'woocommerce'),
				'default'     => '',
				'desc_tip'    => true,
			),
			'merchant_code'   => array(
				'title'   => __('Merchant code', 'ypmn-payment'),
				'type'    => 'text',
				'default' => '',
				'description' => __('Enter merchant code', 'ypmn-payment'),
				'desc_tip'    => true,
			),
			'secret_key'      => array(
				'title'   => __('Secret key', 'ypmn-payment'),
				'type'    => 'password',
				'default' => '',
				'description' => __('Enter sercret key', 'ypmn-payment'),
				'desc_tip'    => true,
			),

			'test_mode'       => array(
				'title'   => __('Test mode', 'ypmn-payment'),
				'type'    => 'select',
				'class'   => 'wc-enhanced-select',
				'options' => array(
					1 => __('test', 'ypmn-payment'),
					0 => __('prod', 'ypmn-payment'),
				),
				'default' => 0,
				'description' => __('Select test mode', 'ypmn-payment'),
				'desc_tip'    => true,
			),

			'product_list'       => array(
				'title'   => __('Product list', 'ypmn-payment'),
				'type'    => 'select',
				'class'   => 'wc-enhanced-select',
				'options' => array(
					1 => __('yes', 'ypmn-payment'),
					0 => __('no', 'ypmn-payment'),
				),
				'default' => 0,
				'description' => __('Send product list', 'ypmn-payment'),
				'desc_tip'    => true,
			),

			'product_tax_id'  => array(
				'title'   => __('VAT', 'ypmn-payment'),
				'type'    => 'select',
				'options' => array(
					1 => __('VAT 0%', 'ypmn-payment'),
					2 => __('VAT 10%', 'ypmn-payment'),
					3 => __('VAT 20%', 'ypmn-payment'),
				),
				'default' => 1,
				'description' => __('Select product tax', 'ypmn-payment'),
				'desc_tip'    => true,
			),
			'delivery_tax_id' => array(
				'title'   => __('Delivery VAT', 'ypmn-payment'),
				'type'    => 'select',
				'options' => array(
					1 => __('VAT 0%', 'ypmn-payment'),
					2 => __('VAT 10%', 'ypmn-payment'),
					3 => __('VAT 20%', 'ypmn-payment'),
				),
				'default' => 1,
				'description' => __('Select delivery tax', 'ypmn-payment'),
				'desc_tip'    => true,
			),

			'ypmn_logging'    => array(
				'title'   => __('Logging', 'ypmn-payment'),
				'type'    => 'select',
				'class'   => 'wc-enhanced-select',
				'options' => array(
					0 => __('disable', 'ypmn-payment'),
					1 => __('enable', 'ypmn-payment'),
				),
				'default' => 0,
				'description' => __('Enable logging', 'ypmn-payment'),
				'desc_tip'    => true,
			),
			'api_details' => array(
				'title'       => __( 'Additional', 'ypmn-payment' ),
				'type'        => 'title',
				'description' => sprintf( __( 'Set callback url "%1$s" in %2$scabinet%3$s', 'ypmn-payment' ), $this->notify_url ,'<a href="https://ypmn.ru/" target="_blank">', '</a>'),
			),
		);
	}

	protected function getDefaultTitle()
	{
		return __('Pay by card', 'ypmn-payment');
	}

	protected function getEnableFieldLabelTitle()
	{
		return __('Enable pay by card', 'ypmn-payment');
	}

	/**
	 * Process the payment and return the result
	 *
	 * @access public
	 * @param int $order_id
	 * @return array
	 */
	public function process_payment($order_id)
	{
		$order = new WC_Order($order_id);

		$ypmnPayment     = $this->createPayment($order);

		$apiRequest      = $this->getApi();
		$responseDataRaw = $apiRequest->sendAuthRequest($ypmnPayment);

		$responseData = json_decode((string) $responseDataRaw["response"], true);

		if (!$responseData) {
			throw new \Exception(esc_html(__('Wrong json', 'ypmn-payment')));
		}
		if ($this->needCheckCode() && !isset($responseData['code'])) {
			throw new \Exception(esc_html(__('Empty response code', 'ypmn-payment')));
		}

		if ($this->needCheckCode() && $responseData['code'] != 200) {
			throw new \Exception(esc_html(sprintf(__('Response code %1$s %2$s', 'ypmn-payment'), $responseData['code'], $responseData['status'])));
		}

		if (!isset($responseData["paymentResult"])) {
			throw new \Exception(esc_html(__('Empty payment result', 'ypmn-payment')));
		}

		$transaction = [
			'order_number'               => $order->get_order_number(),
			'order_id'                   => $order->get_id(),
			'merchant_payment_reference' => $responseData['merchantPaymentReference'],
			'url'                        => $responseData["paymentResult"]['url'],
			'payment_status'             => $responseData['paymentResult']['payuResponseCode'],
			'payment_method'             => $this->payment_method,
			'amount'                     => $responseData['amount'],
			'products'                   => wp_json_encode($ypmnPayment->getProductsArray())
		];

		if ($responseData['payuPaymentReference'] !== 'NOT_YET_REGISTERED') {
			$transaction['payu_payment_reference'] = $responseData['payuPaymentReference'];
		}

		$this->insertTransaction($transaction);
		return array('result' => 'success', 'redirect' => $responseData["paymentResult"]['url']);
	}

	protected function needCheckCode()
	{
		return $this->payment_method !== '';
	}

	protected function createPayment($order)
	{
		$ypmnPayment = new Payment();
		$ypmnPayment->setCurrency('RUB');
		$products = $this->getOrderProducts($order);
		foreach ($products as $product) {
			$ypmnPayment->addProduct($product);
		}
		$merchantPaymentReference = sprintf("%s.%s", $order->get_id(), time());
		$ypmnPayment->setMerchantPaymentReference($merchantPaymentReference);
		$ypmnPayment->setReturnUrl($this->getReturnUrl($order));

		$client = $this->getClient($order);
		$ypmnPayment->setClient($client);

		$authorization = $this->getAuthorization();
		$ypmnPayment->setAuthorization($authorization);

		return $ypmnPayment;
	}

	protected function getReturnUrl($order)
	{
		$url = WC()->api_request_url('Ypmn_Payment_Gateway');

		$resultPage = $this->get_return_url($order);
		if (strpos($url, '?') === false ){
			$url .= '?';
		} else {
			$url .= '&';
		}
		return $url.'action=return_page&page='.urlencode($resultPage);
	}

	protected function getAuthorization()
	{
		$paymentMethodType = $this->payment_method;

		$isPaymentPage = false;

		if ($paymentMethodType === '') {
			$paymentMethodType = null;
		}

		if ($paymentMethodType === PaymentMethods::CCVISAMC) {
			$isPaymentPage = true;
		}

		$authorization = new Authorization($paymentMethodType, $isPaymentPage);
		return $authorization;
	}

	protected function getMerchant()
	{
		$merchant = new Merchant(
			$this->merchant_code,
			$this->secret_key
		);
		return $merchant;
	}

	protected function getApi()
	{
		$merchant = $this->getMerchant();

		$apiRequest = new ApiRequest($merchant);

		if ($this->test_mode) {
			$apiRequest->setSandboxMode();
		}
		return $apiRequest;
	}

	protected function getClient($order)
	{
		$billing = $this->getBilling($order);
		$client  = new Client();
		$client->setBilling($billing);
		$client->setCurrentClientIp();
		$client->setCurrentClientTime();
		return $client;
	}

	protected function getBilling($order)
	{
		$billing = new Billing();
		$billing->setFirstName($order->get_shipping_first_name());
		$billing->setLastName($order->get_shipping_last_name());
		$billing->setPhone($order->get_billing_phone());
		$billing->setEmail($order->get_billing_email());
		$billing->setCountryCode('RU');
		return $billing;
	}

	protected function getOrderProducts($order)
	{
		if (!$this->product_list) {
			$item = [
				"name"      => __('Product', 'ypmn-payment'),
				"sku"       => 'product',
				"quantity"  => 1,
				"unitPrice" => floatval($order->get_total()),
				"vat"       => 1,
			];
			return [new Product($item)];
		}

		$products = [];
		$items    = $order->get_items(['line_item', 'fee', 'shipping']);
		foreach ($items as $item) {
			if ($item->get_total() == 0) {
				continue;
			}
			$taxId = $this->product_tax_id;
			if ($item instanceof WC_Order_Item_Shipping) {
				$taxId = $this->delivery_tax_id;
			}

			$item = [
				"name"      => $item->get_name(),
				"sku"       => strval($item->get_id()),
				"quantity"  => intval($item->get_quantity()),
				"unitPrice" => round(($item->get_total() + $item->get_total_tax()) / $item->get_quantity(), 2),
				"vat"       => intval($taxId),
			];
			$products[] = new Product($item);
		}
		return $products;
	}

	protected function insertTransaction($data)
	{
		global $wpdb;
		$data = array_intersect_key($data, array_flip([
			'order_id',
			'order_number',
			'merchant_payment_reference',
			'payu_payment_reference',
			'amount',
			'payment_status',
			'payment_method',
			'url',
			'date',
			'products',
		]));
		$wpdb->insert("{$wpdb->prefix}ypmn", $data);
	}

	protected function calcSignature($input)
	{

		$date = wp_unslash( $_SERVER['HTTP_X_HEADER_DATE'] ?? '' );
		$date = (new \DateTime($date))->format(\DateTimeInterface::ATOM);
		$uri = wp_unslash($_SERVER['REQUEST_URI'] ?? '');
		$urlParts = wp_parse_url($uri);
        $urlHashableParts = 'POST' . $urlParts['path'];
        if (isset($urlParts['query'])) {
            $urlHashableParts .= $urlParts['query'];
        }
        $hashableString = $this->merchant_code . $date . $urlHashableParts . md5($input);
        return hash_hmac('sha256', $hashableString, $this->secret_key);

	}

	public function notification()
	{
		$action = wp_unslash($_REQUEST['action'] ?? '');
		if ($action == 'return_page') {
			$body = json_decode(wp_unslash($_POST['body'] ?? ''), true);
			$page = sanitize_text_field(wp_unslash($_REQUEST['page'] ?? '').'&status='. wp_unslash($body['status']??''));
			header('Location: '.$page);
			exit();
		}
		// phpcs:disable PHPCompatibility.Variables.RemovedPredefinedGlobalVariables.http_raw_post_dataDeprecatedRemoved
		$rawData = file_get_contents("php://input");
		// phpcs:enable
		if ($this->ypmn_logging) {
			$context = array('source' => 'ypmn-payment');
			$this->logger->info('notify' . ' = ' . $rawData, $context);
		}

		$headerSignature = wp_unslash( $_SERVER['HTTP_X_HEADER_SIGNATURE'] ?? '');

		$signature =  $this->calcSignature($rawData);
		if (strcasecmp($headerSignature, $signature) !== 0 ) {
			throw new \Exception('Sign error');
		}

		$json = json_decode($rawData, true);
		//$json = array_map('sanitize_text_field', $json);
		$apiRequest = $this->getApi();
		$responseData = $apiRequest->sendStatusRequest($json['orderData']['merchantPaymentReference']);
		if ($this->ypmn_logging) {
			$context = array('source' => 'ypmn-payment');
			$this->logger->info('notify' . ' = ' . $responseData["response"], $context);
		}

		$responseData = json_decode((string) $responseData["response"], true);

		if ($responseData['code'] !== 200) {
			throw new \Exception(esc_html($responseData["message"]));
		}

		$transaction = [
			'payment_status' => $responseData['paymentStatus'],
			'merchant_payment_reference' => wp_unslash($json['orderData']['merchantPaymentReference']),
		];

		Ypmn_payment::updateTransaction($transaction);

		list($orderId, ) = explode('.', $json['orderData']['merchantPaymentReference']);

		if (function_exists("wc_get_order")) {
			$order = wc_get_order($orderId);
		} else {
			$order = new WC_Order($orderId);
		}


		if ($responseData['paymentStatus'] === 'PAYMENT_AUTHORIZED') {
			$order->update_status('wc-ypmn_authorized');
		}


		if ($responseData['paymentStatus'] === 'COMPLETE') {
		//if ($responseData['paymentStatus'] === 'PAYMENT_AUTHORIZED') {
			$order->payment_complete($responseData['payuPaymentReference']);
			$order->update_status('completed');
		}
		if (
			$responseData['paymentStatus'] === 'REFUND'
		) {
			$order->update_status('refunded');
		}
		exit();
	}


	public function return_handler($desc, $order)
	{

		global $woocommerce, $wpdb;
		if (!$order) {
			return $desc;
		}
		$order_id = $order->get_id();
		if ($order->get_payment_method() != $this->id) {
			return $desc;
		}

		$status = wp_unslash($_GET['status'] ?? '');

		if ($status == 'SUCCESS') {
			$result = __('Order successfuly payed', 'ypmn-payment');
		} else {
			$result = __('Error', 'ypmn-payment');
		}

		return $result;
	}


}
