<?php
if ( ! defined( 'ABSPATH' ) ) exit;

if (!class_exists('WP_List_Table')) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class Ypmn_Transactions_List extends WP_List_Table
{
	/** Class constructor */
	public function __construct()
	{

		parent::__construct([
			'singular' => __('Transaction', 'ypmn-payment'),
			'plural'   => __('Transactions', 'ypmn-payment'),
			'ajax'     => false,
		]);

	}

	/**
	 * Retrieve transactions data from the database
	 *
	 * @param int $per_page
	 * @param int $page_number
	 *
	 * @return mixed
	 */
	public static function get_transactions($per_page = 20, $page_number = 1)
	{
		global $wpdb;

		$sql = "
		SELECT p.*
		FROM {$wpdb->prefix}ypmn as p";

		$params = [];

		if (!empty($_REQUEST['s'])) {
			$orderNumber = sanitize_text_field(wp_unslash($_REQUEST['s']));
			$sql .= " WHERE p.order_number = %s ";
			$params[] = $orderNumber;
		}

		$orderDir = sanitize_text_field(wp_unslash($_REQUEST['order']??'DESC'));
		if ($orderDir === 'DESC') {
			$sql .= " ORDER BY p.order_number DESC";
		} else {
			$sql .= " ORDER BY p.order_number ASC";
		}

		$sql .= $wpdb->prepare(" LIMIT %d", absint($per_page));
		$sql .= $wpdb->prepare(" OFFSET %d", absint(($page_number - 1) * $per_page));

		$result = $wpdb->get_results($wpdb->prepare($sql, $params), 'ARRAY_A');

		return $result;
	}

	/**
	 * Returns the count of records in the database.
	 *
	 * @return null|string
	 */
	public static function record_count()
	{
		global $wpdb;

		$sql = "SELECT COUNT(*) FROM {$wpdb->prefix}ypmn";
		if (!empty($_REQUEST['s'])) {
			$sql .= " WHERE " ;
			$orderNumber = sanitize_text_field(wp_unslash($_REQUEST['s']));
			$sql .= $wpdb->prepare(" and order_number= %s ", $orderNumber);
		}

		return $wpdb->get_var($sql);
	}

	/** Text displayed when no customer data is available */
	public function no_items()
	{
		echo esc_html(__('No transactions', 'ypmn-payment'));
	}

	public function column_default($item, $column_name)
	{
		return $item[$column_name];
	}

	public function column_info($item)
	{
		$host = sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST'] ?? ''));
		$uri = sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI']??''));
		$currentUrl = set_url_scheme('https://' . $host . $uri);

		$currentUrl  = remove_query_arg(wp_removable_query_args(), $currentUrl);
		$infoLink = add_query_arg('section', 'info', $currentUrl);

		return "<a href='" . add_query_arg('merchant_payment_reference', $item['merchant_payment_reference'], $infoLink) . "'>".__('Information', 'ypmn-payment')."</a>";

	}


	/**
	 *  Associative array of columns
	 *
	 * @return array
	 */
	public function get_columns()
	{
		$columns = [
			'order_number' => __('Order number', 'ypmn-payment'),
			'amount'   => __('Amount', 'ypmn-payment'),
			'date'     => __('Date', 'ypmn-payment'),
			'payment_status'    => __('Status', 'ypmn-payment'),
			'info'  => '',
		];

		return $columns;
	}

	/**
	 * Columns to make sortable.
	 *
	 * @return array
	 */
	public function get_sortable_columns()
	{
		$sortable_columns = array(
			'order_number' => array('order_number', 'asc'),
		);

		return $sortable_columns;
	}

	/**
	 * Handles data query and filter, sorting, and pagination.
	 */
	public function prepare_items()
	{

		$this->_column_headers = $this->get_column_info();

		/** Process bulk action */
		$this->process_bulk_action();

		$per_page     = $this->get_items_per_page('transactions_per_page', 20);
		$current_page = $this->get_pagenum();
		$total_items  = self::record_count();

		$this->set_pagination_args([
			'total_items' => $total_items,
			'per_page'    => $per_page,
		]);

		$this->items = self::get_transactions($per_page, $current_page);
	}
}
