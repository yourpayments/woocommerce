<?php
/*
 * Plugin Name: Ypmn payment
 * Plugin URI: https://ypmn.ru/ru/?utm_source=wp_module
 * Description: Ypmn Payments Gateway
 * Version: 1.0.3
 * Requires at least: 5.2
 * Requires PHP: 7.2
 * Author: Your Payments
 * Author URI: https://ypmn.ru
 * Copyright: © НКО «Твои платежи».
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain: ypmn-payment
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Ypmn_payment
{

	private $transactionsPage;
	private $errorMsg;
	private $logger;

	public function __construct()
	{

		$this->settings = get_option('woocommerce_ypmnpayment_settings');

		if (empty($this->settings['merchant_code'])) {
			$this->settings['merchant_code'] = '';
		}

		if (empty($this->settings['secret_key'])) {
			$this->settings['secret_key'] = '';
		}

		if (empty($this->settings['ypmn_logging'])) {
			$this->settings['ypmn_logging'] = '0';
		}

		add_action('woocommerce_blocks_loaded', [$this, 'registerBlock']);
		add_action('plugins_loaded', [$this, 'initGateway']);
		add_action('woocommerce_init', [$this, 'setLogger']);
		add_filter('wc_order_statuses', [$this, 'addStatus']);
		add_filter('woocommerce_valid_order_statuses_for_payment_complete', [$this, 'addValidStatus']);
		add_filter('woocommerce_register_shop_order_post_statuses', [$this, 'addOrderPostStatus']);
		if (is_admin()) {
			add_action('admin_menu', [$this, 'addMenu']);
			add_action('admin_notices', [$this, 'showMessages']);
		}
	}

	public function setLogger()
	{
		$this->logger = wc_get_logger();
	}

	public function initGateway()
	{
		global $woocommerce;

		if (class_exists('YpmnPayment_Gateway')) {
			return;
		}

		add_action('before_woocommerce_init', [$this, 'declareBlockSupport']);

		//load_plugin_textdomain('ypmn-payment', false, dirname(plugin_basename(__FILE__)) . '/languages/');

		include_once 'includes/class-ypmnpayment-gateway.php';
		include_once 'includes/class-ypmnpayment-info-page.php';
		include_once 'vendor/autoload.php';

		add_filter('woocommerce_payment_gateways', [$this, 'addGateway']);

		if (empty($this->settings['merchant_code']) || $this->settings['enabled'] == 'no') {
			return;
		}

		// Disable for subscriptions until supported
		if (!is_admin() && class_exists('WC_Subscriptions_Cart') && WC_Subscriptions_Cart::cart_contains_subscription() && 'no' === get_option(WC_Subscriptions_Admin::$option_prefix . '_accept_manual_renewals', 'no')) {
			return;
		}

	}

	public function addGateway($methods)
	{
		$methods[] = 'YpmnPayment_Gateway';
		return $methods;
	}

	public function declareBlockSupport()
	{
		if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
		// Declare compatibility for 'cart_checkout_blocks'
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
		}
	}

	public function registerBlock() {
	// Check if the required class exists
		if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
			return;
		}
		// Include the custom Blocks Checkout class
		require_once __DIR__ . '/includes/class-ypmnpayment-gateway-blocks.php';

		// Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
		add_action(
			'woocommerce_blocks_payment_method_type_registration',
			function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
				$payment_method_registry->register( new Ypmnpayment_Gateway_Blocks );
			}
		);
	}

	public function addMenu()
	{
		$icon = 'data:image/svg+xml;base64,' . base64_encode(file_get_contents(__DIR__ . '/assets/images/icons/menu.svg'));
		$hook = add_menu_page(__('ypmn: transactions', 'ypmn-payment'), __('ypmn: transactions', 'ypmn-payment'), 'manage_woocommerce', 'ypmnpayment', [$this, 'pageHandler'], $icon, '55.6');
		add_action("load-$hook", [$this, 'screenOption']);
	}

	public function pageHandler()
	{
		$section = isset($_REQUEST['section']) ? sanitize_text_field(wp_unslash($_REQUEST['section'])) : '';
		if ($section == 'info') {
			$this->infoPage();
		} else {
			$this->transactionsPage();
		}
	}

	public function screenOption()
	{
		$section = isset($_REQUEST['section']) ? sanitize_text_field(wp_unslash($_REQUEST['section'])) : '';
		include_once __DIR__ . '/includes/class-ypmnpayment-transactions-list.php';
		$option = 'per_page';
		$args   = [
			'label'   => __('Transactions', 'ypmn-payment'),
			'default' => 20,
			'option'  => 'transactions_per_page',
		];

		add_screen_option($option, $args);

		$this->transactionsPage = new Ypmnpayment_Transactions_List();
	}

	public function setMessage($text, $type = 'success')
	{
		$message = [
			'type' => $type,
			'text' => $text,
		];
		set_transient(get_current_user_id() . 'ypmnpayment_action_message', $message);
	}

	public function showMessages()
	{
		$transient_id = get_current_user_id() . 'ypmnpayment_action_message';
		if ($message = get_transient($transient_id)) {
			delete_transient($transient_id);
			echo sprintf("<div class='notice notice-%s is-dismissible'> <p>%s </p></div>", esc_html($message['type']), esc_html($message['text']) );
		}
	}

	public function infoPage()
	{
		$page = new Ypmnpayment_Info_Page();
		$page->processAction();
		$page->display();
	}

	public function transactionsPage()
	{
		global $wpdb;
		?>
		<div class="wrap">
			<h2><?php echo esc_html(__("Transactions", 'ypmn-payment')); ?></h2>

			<div id="psbtransactions">
				<form method="post">
					<?php
		$this->transactionsPage->prepare_items();
		$this->transactionsPage->search_box(__('Search', 'woocommerce'), 's');
		$this->transactionsPage->display();?>
				</form>
			</div>
		</div>
		<?php

	}

	public function addStatus($statusList)
	{
		$statusList['wc-ypmnpayment_authorized'] = __('Authorized', 'ypmn-payment');
		return $statusList;
	}

	public function addValidStatus($statusList)
	{
		$statusList[] = 'wc-ypmnpayment_authorized';
		return $statusList;
	}

	public function addOrderPostStatus($statusList)
	{
		$statusList['wc-ypmnpayment_authorized'] = array(
			'label'                     => __('Authorized', 'ypmn-payment'),
			'public'                    => false,
			'exclude_from_search'       => false,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop('Authorized <span class="count">(%s)</span>', 'Authorized <span class="count">(%s)</span>', 'ypmn-payment'),
		);

		return $statusList;
	}


	public static function updateTransaction($data)
	{
		global $wpdb;
		$data = array_intersect_key($data, array_flip([
			'order_id',
			'order_number',
			'merchant_payment_reference',
			'merchant_payment_reference_active',
			'payu_payment_reference',
			'amount',
			'payment_status',
			'payment_method',
			'url',
			'date',
			'products',
		]));
		$wpdb->update("{$wpdb->prefix}ypmnpayment", $data, ['merchant_payment_reference' => $data['merchant_payment_reference']]);
	}
}
$GLOBALS['ypmn_payment'] = new ypmn_payment();

function install_ypmnpayment()
{
	global $wpdb;

	$table_name = $wpdb->prefix . 'ypmnpayment';

	$charset_collate = $wpdb->get_charset_collate();
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$sql = "CREATE TABLE $table_name (
	`merchant_payment_reference` varchar(36) NOT NULL,
	`merchant_payment_reference_active` varchar(36) NULL,
  `order_id` varchar(20) NOT NULL,
  `order_number` varchar(20) NOT NULL,
  `payu_payment_reference` varchar(25) NULL,
  `amount` decimal(10,2) NOT NULL,
  `url` varchar(500) NOT NULL,
  `payment_status` varchar(150) NULL,
  `payment_method` varchar(150) NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `products` text,
  PRIMARY KEY (`merchant_payment_reference`),
  KEY `order_id` (`order_id`),
  KEY `date` (`date`)
)
$charset_collate;";
	dbDelta($sql);
}
register_activation_hook(__FILE__, 'install_ypmnpayment');
