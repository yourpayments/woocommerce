=== Ypmn payment ===
Contributors: yourpayments
Tags: сбп, woocommerce, payment, gateway, yourpayments
Requires at least: 5.2
Tested up to: 6.8
Stable tag: 1.0.3
Requires PHP: 8.2
License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Ypmn Payments Gateway

== Description ==

**Описание**


Приём и отправка платежей различными способами. Быстро, удобно, надёжно!

Модуль интеграции с платёжной системой «Твои Платежи» — это простое и  эффективное решение для приёма платежей на вашем сайте. Он легко позволяет принимать оплату различными  способами: банковскими картами, через СБП, в рассрочку, а также с  помощью популярных сервисов Alfa Pay, Sber Pay и T-Pay.

Почему стоит выбрать модуль интеграции «Твои Платежи»:

Мультибанковский эквайринг. Стабильность и надёжность благодаря маршрутизации между разными банками.
Удобная форма оплаты. Адаптивный дизайн обеспечивает удобство использования как на больших экранах, так и на мобильных устройствах.
Аккуратные и точные расчёты. Исключаем ошибки и обеспечиваем точность финансовых операций.
Подробная отчётность. Отчёты отправляются на электронную почту и доступны в личном кабинете.
Быстрое подключение. Модуль легко устанавливается и настраивается.
Высокая конверсия. Оптимизированная система ускоряет процесс оплаты и повышает лояльность клиентов.
Не упустите возможность упростить процесс оплаты для ваших клиентов и повысить эффективность вашего бизнеса!

**Description**


# Receiving and Sending Payments in Various Ways
**Fast, convenient, and reliable!**

The **“Your Payments” integration module** is a simple and efficient solution for accepting payments on your website.
It allows you to easily accept payments through multiple methods — **bank cards**, **the Faster Payments System (FPS)**, **installment plans**, and popular services such as **Alfa Pay**, **Sber Pay**, and **T-Pay**.

---

## 💡 Why Choose the “Your Payments” Integration Module

- **Multi-bank acquiring**
  Stability and reliability ensured by routing between different banks.

- **User-friendly payment form**
  Adaptive design provides comfort and ease of use on both desktop and mobile devices.

- **Accurate and transparent settlements**
  We eliminate errors and ensure precision in all financial transactions.

- **Detailed reporting**
  Reports are delivered via email and are also available in your personal dashboard.

- **Quick setup**
  The module is easy to install and configure.

- **High conversion rate**
  The optimized system speeds up the payment process and increases customer loyalty.

---

✅ **Don’t miss the opportunity to simplify the payment process for your customers and boost your business efficiency!**



== Installation ==

Скопируйте папку `ypmn-payment` в директорию `wp-content/plugins/` на вашем сервере или установите плагин напрямую через раздел плагинов WordPress.

Зайдите в “Управление сайтом” -> “Плагины”. Активируйте плагин “Твои платежи”.

В управлении сайтом зайдите в “WooCommerce” -> “Настройки” -> “Платежи” -> Твои платежи .
* Отметьте галочкой “Включить оплату по карте”.
* Укажите Код мерчанта и секретный ключ

Нажмите “Сохранить изменения”.

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 1.0.1 =
* Публикация в каталоге
